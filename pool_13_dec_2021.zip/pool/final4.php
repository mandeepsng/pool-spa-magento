<?php
function pr() {
    foreach( func_get_args() as $e ) {
        echo "<pre>";
        print_r( $e );
        echo "</pre>";
    }
}

error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ALL);
$array_valid_urls = array();
$row = 1;

// $newFile = "final2.csv"; //Create a new file for writing
$newFile = "skus_working_file_final.csv"; //Create a new file for writing

// $forlive = '/httpdocs/pub/final.csv';

$finalArray = [];    
if (($handle = fopen($newFile, "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        $row++;
        $id = $data[0];
        $product_id = $data[1];
        $child_sku_id = $data[2];
        $name = $data[4];
        $main_name = $data[5];
        // echo 'Product_id = '.$product_id.', ';
        // echo 'sku_id = '.$sku_id.', ';
        // echo 'child_sku_id = '.$child_sku_id."<br /></p>\n";
        if($product_id != ''){
            $finalArray[] = array( 
                'id' => $id,
                'product_id' => $product_id,
                'child_sku_id' => $child_sku_id,
                'name' => $name,
                'main_name' => $main_name,
            );
        }




   
  }


  
  fclose($handle);
}


      // How to Generate CSV File from Array in PHP Script       
    //   $results = array (  
    //     "0" => array(  
    //          'sadasdasd'
    //     ),  
    //     "1" => array(  
    //         'asdsad'
    //     )  
    // );  
    // code
    
    // get grouped array which have same product_id
    $result = array();
    foreach ($finalArray as $element) {
        $result[$element['product_id']][] = $element;
    }   


    $newresult = array();
    foreach( $result as $k => $v ){

        // get name from $k (sku) for main bundle product
        // get name from $v['sku_id'] and make bundle product name - $k (sku)
        // get all the reuired 
        // name=Two Speed - Hi-Flo - 2hp,type=multi,required=1,sku=637,price=0.0000,default=1,default_qty=1.0000,price_type=fixed,can_change_qty=0|
        // pr($k);
        // pr('===== start=====');

        // if($val['id']  )

        // echo count($v);
        foreach ($v as $val ){
            // pr ($val['id']);
            

            

            // foreach ($val as $element) {
                // }   
                if($k == $val['product_id']){
                    $newresult[$val['product_id']][$val['id']][] = $val;
                    
                }
                
            }
            // pr('===== end =====');
        // pr('=====');
    }

    // pr($newresult);die;
    // code
// final code
$final = [];

    foreach($newresult as $product_id => $v){
        if(count($v) > 1){
        //  pr('===== start ====');
        //  echo 'Product_id = '.$product_id;
        //  echo "<br>no. of array inside = ". count($v)."<br>";
            foreach($v as $id => $val ){
                // echo 'sku_id = '.$id;
                   foreach($val as $child ){
                    //    pr($child['child_sku_id']);
                    $final[$child['product_id']][$child['id']][] = $child;
                   }
               }
            //    pr('===== end =======');
        }

    }
// pr($final);die;
// echo count($final);

// set array 
    $csv = array();
    $data = [];
    foreach($final as $product_id => $v){
        $new_arr = $v;
        $arr = array_shift($new_arr);
        $data[$product_id] = array( 
            'main_sku_id' => "B".$product_id,
            'main_name' => $arr[0]['main_name'], 
        );
        $csv[$product_id] = array(
            'sku' => "B".$product_id,
            'name' => $arr[0]['main_name'], 
        );
        foreach($v as $key => $val ){
            $data[$product_id][$key]['second_child_name'] = $val[0]['name'];
            $data[$product_id][$key][] = $val;
            
            foreach( $val as $l => $child){
                $csv[$product_id]['bundle_values'][] ="name=".$val[0]['name']." - ".$key.",type=select,required=0,sku=" .$child['child_sku_id'].",price=0.00,default=1,default_qty=1.0000,price_type=fixed,can_change_qty=0";
            }
        }        
        
    }
// set array 
unset($csv['10452']);
// echo count($csv);
// pr($csv);
    $csv2 = array();
    foreach( $csv as $c ){
        $csv2[] = array(
            'sku' => $c['sku'],
            'name' => $c['name'],
            'url_key' => str_replace(" ", "-", $c['name'].$c['sku'] ),
            'bundle_values' => implode("|",$c['bundle_values'] ),
        );
    }
    // echo count($csv2);
// pr($csv);


// url_key



// final code



    // die('die');
//    echo '<pre/>';print_R($finalArray);die;
   $filename = '/home/design/Downloads/ready.csv';       
   header("Content-type: text/csv");       
   header("Content-Disposition: attachment; filename=$filename");       
   $output = fopen("php://output", "w");       
   $header = array_keys($csv2[0]);       
   fputcsv($output, $header);       
   foreach($csv2 as $row)       
   {  
        fputcsv($output, $row);  
   }       
   fclose($output); 



// echo '<pre/>';print_R($array_valid_urls);die;
// echo 'ww';

?>
