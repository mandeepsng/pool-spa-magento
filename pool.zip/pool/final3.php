<?php
function pr() {
    foreach( func_get_args() as $e ) {
        echo "<pre>";
        print_r( $e );
        echo "</pre>";
    }
}

error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ALL);
$array_valid_urls = array();
$row = 1;

$newFile = "final3.csv"; //Create a new file for writing
// die('ddd');
// $forlive = '/httpdocs/pub/final.csv';

$finalArray1 = [];    
$finalArray2 = [];    
if (($handle = fopen($newFile, "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        $row++;
        // array 1
        $old_id = $data[0];
        $old_product_id = $data[1];

        // array 2
        $id = $data[3];
        $product_id = $data[4];
        $child_sku_id = $data[5];
        $name = $data[6];
        // echo 'Product_id = '.$product_id.', ';
        // echo 'sku_id = '.$sku_id.', ';
        // echo 'child_sku_id = '.$child_sku_id."<br /></p>\n";
        // if($old_product_id != '' && $old_product_id != 0){
        //     $finalArray1[] = array( 
        //         'old_id' => $old_id,
        //         'old_product_id' => $old_product_id,
        //     );

        // }
        if($product_id != ''){
            $finalArray2[] = array( 
                'id' => $id,
                'product_id' => $product_id,
                'child_sku_id' => $child_sku_id,
                'name' => $name,
            );
        }    




   
  }


  
  fclose($handle);
}


    
    // die;
    // pr($finalArray1);die;    
    // pr('array 1 =>', $finalArray1, 'array 2 => ', $finalArray2);die;    

    
    // get grouped array which have same product_id
    $result = array();
    foreach ($finalArray2 as $element) {
        $result[$element['product_id']][] = $element;
    }   
    // echo count($result);die;
    // pr($result);die;    

    $newresult = array();
    foreach( $result as $k => $v ){

        // get name from $k (sku) for main bundle product
        // get name from $v['sku_id'] and make bundle product name - $k (sku)
        // get all the reuired 
        // name=Two Speed - Hi-Flo - 2hp,type=multi,required=1,sku=637,price=0.0000,default=1,default_qty=1.0000,price_type=fixed,can_change_qty=0|
        // pr($k);
        foreach ($v as $val ){
            // pr ($val['child_sku_id']);
            // foreach ($val as $element) {
                // }   
            if($k == $val['product_id']){
                $newresult[$val['product_id']][$val['id']][] = $val;

            }

        }
        // pr('=====');
    }

    // pr($newresult);die;
    // code
// final code
$final = [];
    foreach($newresult as $product_id => $v){
        if(count($v) > 1){
        //  pr('===== start ====');
        //  echo 'Product_id = '.$product_id;
        //  echo "<br>no. of array inside = ". count($v)."<br>";
         
         foreach($v as $id => $val ){
            //  echo 'sku_id = '.$id."<br>";
                 $existing_count = 1;
                   foreach($val as $child_key => $child ){

                       if(($child['id'] != '' && $child['product_id'] != '' && $child['child_sku_id'] !='' )){
                        // echo "id = " .$child['id']."<br>";
                        // echo "product_id = " .$child['product_id']."<br>";
                        // echo "child_sku_id = ".$child['child_sku_id']."<br>";
                        // echo "existing_count = ".$existing_count."<br>";

                         $existing_count++;
                       }else{

                           if($existing_count >= 1){
                            //    echo " not valid = ". $child['id']." key = ".$child_key."<br>";
                               unset($val[$child_key]);
                            }
                        }
                    $final[$child['product_id']][$child['id']][] = $child;
                   }
               }
            //    pr('===== end =======');
        }

    }

    // foreach($newresult as $product_id => $v){
    //      pr('=====');
    //      echo 'Product_id = '.$product_id;
    //      foreach($v as $sku_id => $val ){
    //          echo 'sku_id = '.$sku_id;
    //             foreach($val as $child ){
    //                 pr($child['child_sku_id']);
    //             }
    //         }
    //     pr('=====');
    // }
        // echo count($final);die;
    pr($final);die;

// final code



    die('die');
   echo '<pre/>';print_R($finalArray);die;
   $filename = '/home/design/Downloads/demo1.csv';       
   header("Content-type: text/csv");       
   header("Content-Disposition: attachment; filename=$filename");       
   $output = fopen("php://output", "w");       
   $header = array_keys($results);       
   fputcsv($output, $header);       
   foreach($results as $row)       
   {  
        fputcsv($output, $row);  
   }       
   fclose($output); 



// echo '<pre/>';print_R($array_valid_urls);die;
// echo 'ww';

?>
