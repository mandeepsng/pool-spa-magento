<?php
function pr() {
    foreach( func_get_args() as $e ) {
        echo "<pre>";
        print_r( $e );
        echo "</pre>";
    }
}

function sluggify($url)
{
    # Prep string with some basic normalization
    $url = strtolower($url);
    $url = strip_tags($url);
    $url = stripslashes($url);
    $url = html_entity_decode($url);

    # Remove quotes (can't, etc.)
    $url = str_replace('\'', '', $url);

    # Replace non-alpha numeric with hyphens
    $match = '/[^a-z0-9]+/';
    $replace = '-';
    $url = preg_replace($match, $replace, $url);

    $url = trim($url, '-');

    return $url;
}

error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ALL);
$array_valid_urls = array();
$row = 1;

// new code 
$type = "group";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "poolandspa";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


// $sql = "SELECT products.*, skus.id as sku FROM products LEFT JOIN skus on products.id = skus.product_id  where skus.sku_package_item_count = 0 ORDER by id";

$sql = "SELECT skus.id, skus.product_id, sku_package_items.child_sku_id , skus.name as child_name, products.description, products.short_description , products.name as main_name  ,sku_package_items.quantity, skus.sku_package_item_count  FROM skus LEFT JOIN sku_package_items on skus.id = sku_package_items.sku_id  LEFT JOIN products on  skus.product_id = products.id  ORDER by skus.product_id";




$finalArray = [];    

// pp($sql);die;
$result = $conn->query($sql);
// $data = [];
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    // echo "<pre>";
    // print_r($row);
    // echo "</pre>";
    // $data[] = $row;

    $num = count($row);
    // $row++;
    $id = $row['id'];
    $product_id = $row['product_id'];
    $child_sku_id = $row['child_sku_id'];
    $name = $row['child_name'];
    $main_name = $row['main_name'];
    $description = $row['description'];
    $short_description = $row['short_description'];
    // echo 'Product_id = '.$product_id.', ';
    // echo 'sku_id = '.$sku_id.', ';
    // echo 'child_sku_id = '.$child_sku_id."<br /></p>\n";
    if($product_id != ''){
        $finalArray[] = array( 
            'id' => $id,
            'product_id' => $product_id,
            'child_sku_id' => $child_sku_id,
            'name' => $name,
            'main_name' => $main_name,
            'description' => $description,
            'short_description' => $short_description,
        );
    }

  }
}








// new code 

// pr($finalArray);
// die('dsfsd');
// 




// $newFile = "final2.csv"; //Create a new file for writing
// $newFile = "skus_working_file_final.csv"; //Create a new file for writing


// $finalArray = [];    
// if (($handle = fopen($newFile, "r")) !== FALSE) {
//     while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
//         $num = count($data);
//         $row++;
//         $id = $data[0];
//         $product_id = $data[1];
//         $child_sku_id = $data[2];
//         $name = $data[4];
//         $main_name = $data[5];
//         // echo 'Product_id = '.$product_id.', ';
//         // echo 'sku_id = '.$sku_id.', ';
//         // echo 'child_sku_id = '.$child_sku_id."<br /></p>\n";
//         if($product_id != ''){
//             $finalArray[] = array( 
//                 'id' => $id,
//                 'product_id' => $product_id,
//                 'child_sku_id' => $child_sku_id,
//                 'name' => $name,
//                 'main_name' => $main_name,
//             );
//         }




   
//   }


  
//   fclose($handle);
// }


      // How to Generate CSV File from Array in PHP Script       
    //   $results = array (  
    //     "0" => array(  
    //          'sadasdasd'
    //     ),  
    //     "1" => array(  
    //         'asdsad'
    //     )  
    // );  
    // code
    
    // get grouped array which have same product_id
    $result = array();
    foreach ($finalArray as $element) {
        $result[$element['product_id']][] = $element;
    }   


    $newresult = array();
    foreach( $result as $k => $v ){

        // get name from $k (sku) for main bundle product
        // get name from $v['sku_id'] and make bundle product name - $k (sku)
        // get all the reuired 
        // name=Two Speed - Hi-Flo - 2hp,type=multi,required=1,sku=637,price=0.0000,default=1,default_qty=1.0000,price_type=fixed,can_change_qty=0|
        // pr($k);
        // pr('===== start=====');

        // if($val['id']  )

        // echo count($v);
        foreach ($v as $val ){
            // pr ($val['id']);
            

            

            // foreach ($val as $element) {
                // }   
                if($k == $val['product_id']){
                    $newresult[$val['product_id']][$val['id']][] = $val;
                    
                }
                
            }
            // pr('===== end =====');
        // pr('=====');
    }

    // pr($newresult);die;
// echo count($newresult);die;

    // code
// final code
$final = [];

    foreach($newresult as $product_id => $v){
        $status = "";
        if(count($v) > 1){
        //  pr('===== start ====');
        //  echo 'Product_id = '.$product_id;
        //  echo "<br>no. of array inside = ". count($v)."<br>";
        //  echo "<br>no. of array inside = ".  pr($v) ."<br>";

            foreach($v as $id => $val ){
                // echo ' sku_id = '.$id;
                // echo ' cont = > '. count($val);
                if(count($val) > 1 ){
                    // $final[$child['product_id']][$child['id']][] = 'B';
                    $status = "B";   
                }else{
                    $status = "G";
                }
                
                   foreach($val as $child ){
                    //    pr($child['child_sku_id']);
                    $final[$child['product_id']][$child['id']][] = $child;
                   }
               }
            //    pr('===== end =======');
        }
        if($status == "B"){
            $final[$child['product_id']]['status'] =  $status;
        }

    }

$fianlbundle = [];
$fianlgroup = [];

foreach($final as $k_i => $fbi ){
    if(isset($fbi['status'])){
        unset($fbi['status']);
        $fianlbundle[$k_i] = $fbi;
        // $final[$k_i['product_id']][$k_i['id']][] = $child;
    }else{
        $fianlgroup[$k_i] = $fbi;
    }
}






unset($fianlgroup[0]);
// pr($fianlbundle);die;
// pr($fianlgroup);die;

if($type == 'group'){
// set array===========================================  Group ===========================================================================
$csv = array();
$data = [];
foreach($fianlgroup as $product_id => $v){
    $new_arr = $v;
    $arr = array_shift($new_arr);
    $csv[$product_id] = array(
        'sku' => "G".$product_id,
        'name' => $arr[0]['main_name'], 
        'short_description' => $arr[0]['short_description'], 
        'description' => $arr[0]['description'], 
    );
   
    foreach($v as $key => $val ){
        $data[$product_id][$key]['child_id'] = $val[0]['id'];
        // $data[$product_id][$key]['associated_skus'] = $val[0]['id'];
        foreach( $val as $l => $child){
            $csv[$product_id]['associated_skus'][] =$val[0]['id']."=0";
        }
    }   

  
}
// die;
// pr($csv);die;
$csv2 = array();
foreach( $csv as $c ){
    $csv2[] = array(
        'sku' => $c['sku'],
        'name' => $c['name'],
        'url_key' => sluggify($c['name'].'-'.$c['sku'] ),
        'associated_skus' => implode(",",$c['associated_skus'] ),
        'attribute_set_code' => 'Default',
        'product_type' => 'grouped',
        'categories' => 'Default Category',
        'product_websites' => 'base',
        'short_description' => $c['short_description'],
        'product_online' => '1',
        'visibility' => 'Catalog, Search',
    );
}


}else{

// set array===========================================  Bundle ===========================================================================

$csv = array();
$data = [];
foreach($fianlbundle as $product_id => $v){
    $new_arr = $v;
    $arr = array_shift($new_arr);
    $data[$product_id] = array( 
        'main_sku_id' => "B".$product_id,
        'main_name' => $arr[0]['main_name'], 
    );
    $csv[$product_id] = array(
        'sku' => "B".$product_id,
        'name' => $arr[0]['main_name'], 
    );
    foreach($v as $key => $val ){
        $data[$product_id][$key]['second_child_name'] = $val[0]['name'];
        $data[$product_id][$key][] = $val;

        
        foreach( $val as $l => $child){
            $csv[$product_id]['bundle_values'][] ="name=".$val[0]['name']." - ".$key.",type=multi,required=1,sku=" .$child['child_sku_id'].",price=0.00,default=1,default_qty=1.0000,price_type=fixed,can_change_qty=0";
        }
    }        
    
}



$csv2 = array();
foreach( $csv as $c ){
    $csv2[] = array(
        'sku' => $c['sku'],
        'name' => $c['name'],
        'url_key' => sluggify($c['name'].'-'.$c['sku'] ),
        'bundle_values' => implode("|",$c['bundle_values'] ),
        'attribute_set_code' => 'Default',
        'product_type' => 'bundle',
        'product_websites' => 'base',
        'product_online' => '1',
        'tax_class_name' => 'Taxable Goods',
        'visibility' => 'Catalog, Search',
        'bundle_price_type' => 'dynamic',
        'bundle_sku_type' => 'dynamic',
        'bundle_price_view' => 'Price range',
        'bundle_weight_type' => 'dynamic',
        'bundle_shipment_type' => 'together',
    );
}

}

// pr($csv2);die;

// echo count($fianlgroup);die;
// echo count($fianlbundle);die;

// set array 
    // $csv = array();
    // $data = [];
    // foreach($fianlbundle as $product_id => $v){
    //     $new_arr = $v;
    //     $arr = array_shift($new_arr);
    //     $data[$product_id] = array( 
    //         'main_sku_id' => "B".$product_id,
    //         'main_name' => $arr[0]['main_name'], 
    //     );
    //     $csv[$product_id] = array(
    //         'sku' => "B".$product_id,
    //         'name' => $arr[0]['main_name'], 
    //     );
    //     foreach($v as $key => $val ){
    //         $data[$product_id][$key]['second_child_name'] = $val[0]['name'];
    //         $data[$product_id][$key][] = $val;

            
    //         foreach( $val as $l => $child){
    //             $csv[$product_id]['bundle_values'][] ="name=".$val[0]['name']." - ".$key.",type=multi,required=1,sku=" .$child['child_sku_id'].",price=0.00,default=1,default_qty=1.0000,price_type=fixed,can_change_qty=0";
    //         }
    //     }        
        
    // }
// set array 
// unset($csv['10452']);
// echo count($csv);
// pr($csv);
    // $csv2 = array();
    // foreach( $csv as $c ){
    //     $csv2[] = array(
    //         'sku' => $c['sku'],
    //         'name' => $c['name'],
    //         'url_key' => sluggify($c['name'].'-'.$c['sku'] ),
    //         'bundle_values' => implode("|",$c['bundle_values'] ),
    //         'attribute_set_code' => 'Default',
    //         'product_type' => 'bundle',
    //         'product_websites' => 'base',
    //         'product_online' => '1',
    //         'tax_class_name' => 'Taxable Goods',
    //         'visibility' => 'Catalog, Search',
    //         'bundle_price_type' => 'dynamic',
    //         'bundle_sku_type' => 'dynamic',
    //         'bundle_price_view' => 'Price range',
    //         'bundle_weight_type' => 'dynamic',
    //         'bundle_shipment_type' => 'together',
    //     );
    // }
    // echo count($csv2);
// pr($csv2);die;


// url_key



// final code



    // die('die');
//    echo '<pre/>';print_R($finalArray);die;
   $filename = 'group.csv';       
   header("Content-type: text/csv");       
   header("Content-Disposition: attachment; filename=$filename");       
   $output = fopen("php://output", "w");       
   $header = array_keys($csv2[0]);       
   fputcsv($output, $header);       
   foreach($csv2 as $row)       
   {  
        fputcsv($output, $row);  
   }       
   fclose($output); 



// echo '<pre/>';print_R($array_valid_urls);die;
// echo 'ww';

?>
